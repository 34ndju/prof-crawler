[![Forward Data
Lab](/_/rsrc/1493351152071/config/customLogo.gif?revision=2)](http://www.forwarddatalab.org/)

## [Forward Data Lab](http://www.forwarddatalab.org/)

|

Search this site  
  
---|---  
  
  * [Home](/home)
  * [Research](/research)
  * [Publications](/publications)
  * [People](/people)
  * [Demos](/demos)
  * [Code/Datasets](/software-datasets)

  
  
  * [Home](/home)

  * [Sitemap](/system/app/pages/sitemap/hierarchy)

|

[[Untitled]](/system)‎ > ‎[[Untitled]](/system/app)‎ >
‎[[Untitled]](/system/app/pages)‎ > ‎

###  Recent site activity

|

|  ** Jan 17, 2018, 11:35 AM ** |  Kevin Chang edited [Kevin Chen-Chuan
Chang](http://www.forwarddatalab.org/kevinchang)  
---|---  
** May 30, 2017, 11:01 AM ** |  Kevin Chang edited
[Publications](http://www.forwarddatalab.org/kevinchang/publications)  
** May 30, 2017, 11:00 AM ** |  Kevin Chang edited [Kevin Chen-Chuan
Chang](http://www.forwarddatalab.org/kevinchang)  
** Apr 6, 2017, 8:20 AM ** |  Kevin Chang edited [Kevin Chen-Chuan
Chang](http://www.forwarddatalab.org/kevinchang)  
** Apr 6, 2017, 8:12 AM ** |  Kevin Chang edited [Kevin Chen-Chuan
Chang](http://www.forwarddatalab.org/kevinchang)  
** Apr 5, 2017, 5:40 AM ** |  Kevin Chang edited [Kevin Chen-Chuan
Chang](http://www.forwarddatalab.org/kevinchang)  
** Apr 5, 2017, 5:39 AM ** |  Kevin Chang edited [Kevin Chen-Chuan
Chang](http://www.forwarddatalab.org/kevinchang)  
** Mar 25, 2017, 8:59 AM ** |  Kevin Chang edited
[Publications](http://www.forwarddatalab.org/kevinchang/publications)  
** Mar 25, 2017, 8:59 AM ** |  Kevin Chang edited
[Publications](http://www.forwarddatalab.org/kevinchang/publications)  
** Mar 25, 2017, 8:57 AM ** |  Kevin Chang edited
[Home](http://www.forwarddatalab.org/home)  
** Mar 25, 2017, 8:57 AM ** |  Kevin Chang edited [Kevin Chen-Chuan
Chang](http://www.forwarddatalab.org/kevinchang)  
** Mar 25, 2017, 8:56 AM ** |  Kevin Chang edited
[Publications](http://www.forwarddatalab.org/publications)  
** Mar 13, 2017, 1:42 PM ** |  Kevin Chang edited
[Publications](http://www.forwarddatalab.org/publications)  
** Mar 13, 2017, 1:42 PM ** |  Kevin Chang deleted attachment
[framework.pdf](http://www.forwarddatalab.org/system/errors/NodeNotFound?suri=wuid:gx:32148e0b05b8e623)
from [Publications](http://www.forwarddatalab.org/publications)  
** Mar 13, 2017, 1:41 PM ** |  Kevin Chang attached
[framework.pdf](http://www.forwarddatalab.org/system/errors/NodeNotFound?suri=wuid:gx:32148e0b05b8e623)
to [Publications](http://www.forwarddatalab.org/publications)  
** Mar 13, 2017, 1:40 PM ** |  Kevin Chang edited
[Publications](http://www.forwarddatalab.org/publications)  
** Mar 9, 2017, 7:18 PM ** |  Kevin Chang edited
[Publications](http://www.forwarddatalab.org/kevinchang/publications)  
** Feb 21, 2017, 5:52 AM ** |  Kevin Chang edited
[SIGIR-2017](http://www.forwarddatalab.org/forwarders/review/sigir-2017)  
** Feb 21, 2017, 5:50 AM ** |  Kevin Chang created
[SIGIR-2017](http://www.forwarddatalab.org/forwarders/review/sigir-2017)  
** Jan 30, 2017, 5:05 AM ** |  Kevin Chang edited
[Publications](http://www.forwarddatalab.org/kevinchang/publications)  
** Jan 30, 2017, 5:03 AM ** |  Kevin Chang edited
[Publications](http://www.forwarddatalab.org/publications)  
** Jan 29, 2017, 3:27 PM ** |  Kevin Chang edited
[Home](http://www.forwarddatalab.org/home)  
** Jan 29, 2017, 3:26 PM ** |  Kevin Chang edited [Kevin Chen-Chuan
Chang](http://www.forwarddatalab.org/kevinchang)  
** Jan 29, 2017, 3:25 PM ** |  Kevin Chang edited [Kevin Chen-Chuan
Chang](http://www.forwarddatalab.org/kevinchang)  
** Jan 29, 2017, 3:24 PM ** |  Kevin Chang edited
[Home](http://www.forwarddatalab.org/home)  
  
[older](?offset=25) | newer  
  
[Sign
in](https://www.google.com/a/UniversalLogin?continue=http://sites.google.com/site/forwarddatalab/system/app/pages/recentChanges&service=jotspot)|[Recent
Site Activity](/system/app/pages/recentChanges)|[Report
Abuse](http://sites.google.com/site/forwarddatalab/system/app/pages/reportAbuse)|Powered
By **[Google Sites](http://sites.google.com)**

